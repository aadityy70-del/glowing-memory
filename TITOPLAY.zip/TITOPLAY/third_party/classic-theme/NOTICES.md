# Classic theme font notices

- EB Garamond and its italic face: SIL Open Font License 1.1; see `OFL-EBGaramond.txt`.
- Montserrat: SIL Open Font License 1.1; see `OFL-Montserrat.txt`.
- Pinyon Script: SIL Open Font License 1.1; see `OFL-PinyonScript.txt`.
- The neon TITOPLAY mark is supplied by the user for this project.
