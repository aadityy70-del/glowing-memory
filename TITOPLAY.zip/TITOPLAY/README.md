# TITOPLAY

Music player by **Aditya Yadav** (Titonox).

- Instagram: https://www.instagram.com/titonoxofficial
- YouTube: https://www.youtube.com/@titonoxofficial

Open source under GPL-3.0, based on work by Lelonio. See `NOTICE.md` and `LICENSE`.

## Alternate visual skin

Long-press the Home tab for five seconds to switch between the current TITOPLAY skin and the Classic TITOPLAY skin. A progress ring fills around the Home icon; the app then performs a rotating fade/flip transition. The selected skin is saved on this device.

Both skins are presentation modes inside the same app and use the same navigation, playback engine, Spotify session and YouTube Music account session. Switching skins does not sign out or create a second account. Spotify and YouTube Music remain separate provider logins, as before.
