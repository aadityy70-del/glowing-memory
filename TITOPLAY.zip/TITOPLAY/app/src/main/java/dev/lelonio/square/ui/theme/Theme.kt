package dev.lelonio.square.ui.theme

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import dev.lelonio.square.R

/**
 * Glass over the album art.
 *
 * The page is the record that is playing — a colour taken from the artwork,
 * never a flat sheet — and the system's setting decides which way that colour
 * is taken. Dark takes it down towards the floor and puts light ink and a dark
 * film of glass on it; light takes the same colour up towards paper and puts
 * dark ink and a white film on it. One palette, read in two directions, rather
 * than two palettes.
 *
 * `background` is transparent on purpose: whatever draws the backdrop sits
 * behind the whole tree, and an opaque page colour would cover it.
 *
 * What follows is the original note, still true of the accent:
 *
 * The neutrals do all the structural work — page, cards, text, borders are a
 * single grey ramp — and the accent seeded from the current cover is spent only
 * where the interface needs to say "this one, right now": the play button, the
 * played part of the waveform, an enabled toggle, the current row. Kept that
 * narrow, colour reads as state rather than as decoration, and the covers stay
 * the most colourful thing on screen.
 *
 * The seed is pushed toward legibility rather than used raw: a cover's dominant
 * colour is as likely to be near-black as near-white, and either one vanishes
 * against the wrong background.
 */
/**
 * Which side the app is on, said plainly.
 *
 * Read off the scheme's own surface at first, and that was wrong in a way that
 * only showed on the other side: every film in this design is a translucent
 * *white*, so `surface.luminance()` is 1.0 in both settings — alpha is not part
 * of luminance. Everything keyed on it would have called the dark theme light.
 */
val LocalLightTheme = staticCompositionLocalOf { false }

/**
 * The visual skin chosen by the app shell. Nullable until the outer theme
 * resolves the saved preference; nested theme scopes inherit the same skin.
 */
val LocalClassicSkin = staticCompositionLocalOf<Boolean?> { null }

@Composable
fun SquareTheme(
    /** Dominant colour of the current artwork, or null before anything plays. */
    seed: Color? = null,
    darkTheme: Boolean = isSystemInDarkTheme(),
    /** Only the app shell should animate the full-window skin flip. */
    animateSkinTransitions: Boolean = false,
    content: @Composable () -> Unit,
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val preferences = remember(context) {
        (context.applicationContext as? dev.lelonio.square.SquareApplication)?.preferences
    }
    val preferredSkin by remember(preferences) {
        preferences?.classicTheme ?: kotlinx.coroutines.flow.MutableStateFlow(false)
    }.collectAsState()

    val inheritedSkin = LocalClassicSkin.current
    val ownsSkinTransition = inheritedSkin == null && animateSkinTransitions
    var displayedClassicSkin by remember { mutableStateOf(preferredSkin) }
    val flipRotation = remember { Animatable(0f) }
    val flipAlpha = remember { Animatable(1f) }

    // The screen turns on its vertical axis. At the edge-on midpoint the new
    // palette and type system are installed, then the page turns back into view.
    // The screen tree itself is never replaced, so the player, navigation and
    // login composables keep their existing state.
    LaunchedEffect(preferredSkin, ownsSkinTransition) {
        if (ownsSkinTransition && displayedClassicSkin != preferredSkin) {
            flipAlpha.snapTo(1f)
            flipRotation.snapTo(0f)
            flipRotation.animateTo(88f, tween(260))
            displayedClassicSkin = preferredSkin
            flipRotation.snapTo(-88f)
            flipAlpha.snapTo(0.06f)
            flipRotation.animateTo(0f, tween(360))
            flipAlpha.animateTo(1f, tween(360))
        } else if (!ownsSkinTransition) {
            displayedClassicSkin = preferredSkin
        }
    }

    val classicSkin = inheritedSkin ?: if (ownsSkinTransition) displayedClassicSkin else preferredSkin
    val effectiveDarkTheme = classicSkin || darkTheme
    val base = seed ?: if (classicSkin) ClassicSignal else DefaultAccent
    val accent = if (effectiveDarkTheme) {
        base.liftFor(if (classicSkin) Color.Black else DarkBase)
    } else {
        base.deepenFor(LightBase)
    }

    // Animated so a track change slides the accent across instead of snapping.
    val animatedAccent by animateColorAsState(accent, tween(600), label = "accent")

    val scheme = remember(animatedAccent, effectiveDarkTheme, classicSkin) {
        val ink = if (effectiveDarkTheme) DarkInk else LightInk
        val film = if (effectiveDarkTheme) DarkFilm else LightFilm
        val filmStrong = if (effectiveDarkTheme) DarkFilmStrong else LightFilmStrong
        if (effectiveDarkTheme) {
            darkColorScheme(
                primary = animatedAccent,
                onPrimary = Color(0xFF0B0D10),
                primaryContainer = film,
                onPrimaryContainer = ink,
                secondary = ink.copy(alpha = 0.66f),
                background = Color.Transparent,
                onBackground = ink,
                surface = if (classicSkin) Color(0xFF0D0D0D).copy(alpha = 0.78f) else film,
                onSurface = ink,
                surfaceVariant = filmStrong,
                onSurfaceVariant = ink.copy(alpha = 0.66f),
                outlineVariant = Color.White.copy(alpha = if (classicSkin) 0.10f else 0.16f),
            )
        } else {
            lightColorScheme(
                primary = animatedAccent,
                onPrimary = Color(0xFFFFFFFF),
                primaryContainer = film,
                onPrimaryContainer = ink,
                secondary = ink.copy(alpha = 0.66f),
                background = Color.Transparent,
                onBackground = ink,
                surface = film,
                onSurface = ink,
                surfaceVariant = filmStrong,
                onSurfaceVariant = ink.copy(alpha = 0.66f),
                outlineVariant = Color.Black.copy(alpha = 0.14f),
            )
        }
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as android.app.Activity).window
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = !effectiveDarkTheme
                isAppearanceLightNavigationBars = !effectiveDarkTheme
            }
        }
    }

    val density = LocalDensity.current
    val inheritedPureBlack = LocalPureBlack.current
    val currentConfiguration = LocalConfiguration.current
    val themedConfiguration = remember(currentConfiguration, effectiveDarkTheme) {
        android.content.res.Configuration(currentConfiguration).apply {
            val nightMode = if (effectiveDarkTheme) {
                android.content.res.Configuration.UI_MODE_NIGHT_YES
            } else {
                android.content.res.Configuration.UI_MODE_NIGHT_NO
            }
            uiMode = (uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK.inv()) or nightMode
        }
    }
    CompositionLocalProvider(
        LocalConfiguration provides themedConfiguration,
        LocalLightTheme provides !effectiveDarkTheme,
        LocalClassicSkin provides classicSkin,
        LocalPureBlack provides (inheritedPureBlack || classicSkin),
    ) {
        val systemFont by remember(context) {
            preferences?.systemFont ?: kotlinx.coroutines.flow.MutableStateFlow(false)
        }.collectAsState()
        MaterialTheme(
            colorScheme = scheme,
            typography = when {
                classicSkin -> ClassicTypography
                systemFont -> SystemTypography
                else -> SpotTypography
            },
        ) {
            if (ownsSkinTransition) {
                Box(
                    Modifier
                        .fillMaxSize()
                        .graphicsLayer {
                            rotationY = flipRotation.value
                            alpha = flipAlpha.value
                            cameraDistance = 32f * density.density
                        },
                ) { content() }
            } else {
                content()
            }
        }
    }
}

private val ClassicSignal = Color(0xFFFF3B30)

private val ClassicScript = FontFamily(
    Font(R.font.pinyon_script, FontWeight.Normal),
)
private val ClassicSerif = FontFamily(
    Font(R.font.eb_garamond, FontWeight.Normal),
    Font(R.font.eb_garamond_italic, FontWeight.Normal, style = FontStyle.Italic),
)
private val ClassicSans = FontFamily(
    Font(R.font.montserrat, FontWeight.Normal),
)

private val ClassicTypography = Typography(
    displayLarge = TextStyle(fontFamily = ClassicScript, fontSize = 48.sp, lineHeight = 54.sp, fontWeight = FontWeight.Normal),
    displayMedium = TextStyle(fontFamily = ClassicScript, fontSize = 40.sp, lineHeight = 46.sp, fontWeight = FontWeight.Normal),
    displaySmall = TextStyle(fontFamily = ClassicScript, fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.Normal),
    headlineLarge = TextStyle(fontFamily = ClassicSerif, fontSize = 30.sp, lineHeight = 36.sp, fontWeight = FontWeight.Normal),
    headlineMedium = TextStyle(fontFamily = ClassicSerif, fontSize = 25.sp, lineHeight = 31.sp, fontWeight = FontWeight.Normal),
    headlineSmall = TextStyle(fontFamily = ClassicSerif, fontSize = 21.sp, lineHeight = 27.sp, fontWeight = FontWeight.Normal),
    titleLarge = TextStyle(fontFamily = ClassicSerif, fontSize = 18.sp, lineHeight = 23.sp, fontWeight = FontWeight.Medium),
    titleMedium = TextStyle(fontFamily = ClassicSans, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.0.sp),
    titleSmall = TextStyle(fontFamily = ClassicSans, fontSize = 11.sp, lineHeight = 15.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.7.sp),
    bodyLarge = TextStyle(fontFamily = ClassicSerif, fontSize = 17.sp, lineHeight = 23.sp, fontWeight = FontWeight.Normal),
    bodyMedium = TextStyle(fontFamily = ClassicSerif, fontSize = 15.sp, lineHeight = 20.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontFamily = ClassicSerif, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontFamily = ClassicSans, fontSize = 10.sp, lineHeight = 14.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.4.sp),
    labelMedium = TextStyle(fontFamily = ClassicSans, fontSize = 9.sp, lineHeight = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.0.sp),
    labelSmall = TextStyle(fontFamily = ClassicSans, fontSize = 8.sp, lineHeight = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.7.sp),
)

private val DarkBase = Color(0xFF0D0E11)
private val LightBase = Color(0xFFF1F2F6)

/**
 * The film every glass surface is tinted with.
 *
 * White over a dark page and white-with-more-of-it over a light one: the
 * material is the same, and what changes is how much of the page is left
 * showing through. The glass code decides its own tint from whether this colour
 * is light or dark, so these are also the switch for that; see GlassEffect.
 */
private val DarkFilm = Color.White.copy(alpha = 0.10f)
private val DarkFilmStrong = Color.White.copy(alpha = 0.16f)
private val LightFilm = Color.White.copy(alpha = 0.55f)
private val LightFilmStrong = Color.White.copy(alpha = 0.72f)

/** Text and icons, on whichever side of the page they have to be read from. */
private val DarkInk = Color(0xFFF7F8FA)
private val LightInk = Color(0xFF15161A)

/**
 * The colour text and icons are drawn in.
 *
 * A composable getter rather than a constant, so the eighty-odd places that
 * name it did not have to learn about the theme: it is the scheme's own
 * onSurface, which is light over a dark page and dark over a light one.
 */
val Ink: Color
    @Composable get() = LocalInkOverride.current ?: MaterialTheme.colorScheme.onSurface

/**
 * The app's own ink, whatever the page around it has done to the theme: for a
 * surface that keeps the app's colours on a page coloured by its cover — a
 * menu, which is a light pane on the light side and a dark one on the dark.
 */
val AppInk: Color
    @Composable get() = if (lightPage()) LightInk else DarkInk

/** The same, for what is said quietly. */
val InkDim: Color
    @Composable get() = Ink.copy(alpha = 0.66f)

/**
 * Fallback accent, used until artwork provides one.
 *
 * Muted lilac rather than a green: Spotify's brand colour is 0xFF1DB954, and
 * anything near it makes the app read as a clone no matter how the rest is laid
 * out.
 */
private val DefaultAccent = Color(0xFF7C5CE6)

/** Brighten until the colour reads against a near-black background. */
private fun Color.liftFor(background: Color): Color {
    val floor = background.luminance() + 0.16f
    if (luminance() >= floor) return this
    val amount = ((floor - luminance()) * 2f).coerceIn(0f, 1f)
    return Color(
        red = red + (1f - red) * amount,
        green = green + (1f - green) * amount,
        blue = blue + (1f - blue) * amount,
    )
}

/**
 * Darken until the colour reads against a near-white background.
 *
 * Taken further than it was. At the old ceiling a mid-tan came out of this
 * barely touched, and the accent is spent on exactly the things that have to be
 * found at a glance — the lit tab, the play button, the row that is playing —
 * so "technically darker than the page" is not enough for it.
 */
private fun Color.deepenFor(background: Color): Color {
    val ceiling = background.luminance() - 0.62f
    if (luminance() <= ceiling) return this
    val amount = ((luminance() - ceiling) * 1.6f).coerceIn(0f, 0.86f)
    return Color(
        red = red * (1f - amount),
        green = green * (1f - amount),
        blue = blue * (1f - amount),
    )
}

/**
 * The wide, soft, low-opacity drop shadow this design leans on.
 *
 * Elevation is the only depth cue left once colour is gone, so it does the work
 * that an accent used to: cards, covers and the mini player read as separate
 * layers rather than as regions of one flat sheet. Kept very diffuse — a tight
 * shadow at this size looks like a border and flattens the effect.
 */
fun Modifier.softShadow(
    shape: Shape,
    elevation: Dp = 18.dp,
    ambient: Float = 0.10f,
    spot: Float = 0.13f,
): Modifier = shadow(
    elevation = elevation,
    shape = shape,
    clip = false,
    ambientColor = Color.Black.copy(alpha = ambient),
    spotColor = Color.Black.copy(alpha = spot),
)

/**
 * Editorial rather than utilitarian: a large, tightly tracked display face
 * against small wide-tracked labels. The contrast between the two is what makes
 * a screen read as designed instead of as a list of controls.
 */
private fun spotTypography(family: FontFamily, tracking: Float) = Typography(
    displayLarge = TextStyle(
        fontFamily = family,
        fontSize = 34.sp,
        lineHeight = 38.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-1.2 * tracking).sp,
    ),
    headlineLarge = TextStyle(
        fontFamily = family,
        fontSize = 27.sp,
        lineHeight = 31.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.8 * tracking).sp,
    ),
    titleLarge = TextStyle(fontFamily = family, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, letterSpacing = (-0.3 * tracking).sp),
    titleMedium = TextStyle(fontFamily = family, fontSize = 15.5.sp, fontWeight = FontWeight.Medium, letterSpacing = (-0.1 * tracking).sp),
    bodyMedium = TextStyle(fontFamily = family, fontSize = 13.5.sp, fontWeight = FontWeight.Normal),
    bodySmall = TextStyle(fontFamily = family, fontSize = 12.sp, fontWeight = FontWeight.Normal),
    labelLarge = TextStyle(fontFamily = family, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 1.2.sp),
)

private val SpotTypography = spotTypography(Inter, tracking = 1f)

/**
 * The same scale in the phone's own face. Tracked half as tight: the negative
 * spacing was set for Inter's shapes, and on a wider system face it crowded
 * the letters of a large title together.
 */
private val SystemTypography = spotTypography(FontFamily.Default, tracking = 0.5f)

/**
 * The listener's light or dark, over the phone's; see PreferencesStore.themeMode.
 *
 * Put in as the configuration's own night mode rather than handed to the
 * theme: `isSystemInDarkTheme` is read in the theme and in the glass
 * components on their own, and every one of them reads it from here. Nothing
 * else in the configuration is touched, and on "system" it is the phone's,
 * untouched.
 */
@Composable
fun ChosenTheme(content: @Composable () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val mode by remember(context) {
        (context.applicationContext as? dev.lelonio.square.SquareApplication)?.preferences?.themeMode
            ?: kotlinx.coroutines.flow.MutableStateFlow(dev.lelonio.square.data.PreferencesStore.ThemeMode.SYSTEM)
    }.collectAsState()
    val base = androidx.compose.ui.platform.LocalConfiguration.current
    val night = when (mode) {
        dev.lelonio.square.data.PreferencesStore.ThemeMode.SYSTEM -> null
        dev.lelonio.square.data.PreferencesStore.ThemeMode.LIGHT -> android.content.res.Configuration.UI_MODE_NIGHT_NO
        dev.lelonio.square.data.PreferencesStore.ThemeMode.DARK -> android.content.res.Configuration.UI_MODE_NIGHT_YES
    }
    val configuration = remember(base, night) {
        if (night == null) {
            base
        } else {
            android.content.res.Configuration(base).apply {
                uiMode = (uiMode and android.content.res.Configuration.UI_MODE_NIGHT_MASK.inv()) or night
            }
        }
    }
    val pureBlack by remember(context) {
        (context.applicationContext as? dev.lelonio.square.SquareApplication)?.preferences?.pureBlack
            ?: kotlinx.coroutines.flow.MutableStateFlow(false)
    }.collectAsState()
    CompositionLocalProvider(
        androidx.compose.ui.platform.LocalConfiguration provides configuration,
        LocalPureBlack provides pureBlack,
        content = content,
    )
}
