package dev.lelonio.square.ui.components

import androidx.compose.foundation.ScrollState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.systemGestureExclusion
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * A row that scrolls sideways fading out at an edge it has more beyond,
 * rather than ending in a cut through whatever is passing it: a chip or a
 * lit pill sliced at the edge reads as a mistake (#166). Each edge fades only
 * while there is more of the row past it, and only as far as there is.
 */
fun Modifier.horizontalEdgeFade(state: ScrollState, width: Dp = 24.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val fade = width.toPx()
        if (fade <= 0f || size.width <= 0f) return@drawWithContent
        val start = (state.value / fade).coerceIn(0f, 1f)
        val end = ((state.maxValue - state.value) / fade).coerceIn(0f, 1f)
        if (start <= 0f && end <= 0f) return@drawWithContent
        val share = (fade / size.width).coerceAtMost(0.5f)
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Black.copy(alpha = 1f - start),
                share to Color.Black,
                1f - share to Color.Black,
                1f to Color.Black.copy(alpha = 1f - end),
            ),
            blendMode = BlendMode.DstIn,
        )
    }

/**
 * For a row that scrolls sideways from one edge of the screen to the other:
 * keeps the system's back gesture off it. With gesture navigation a drag that
 * starts at either edge is "back", and a row of chips or presets runs right to
 * both, so trying to scroll it from where it starts left the tab or closed the
 * page instead (#172). The row is short, well inside the room Android allows an
 * app to take from each edge, and the back gesture still works everywhere else.
 */
val SideScrollNoBack: Modifier = Modifier.systemGestureExclusion()

/**
 * The colour the top and bottom fades (and the pinned headings) melt into.
 * SquareApp sets it from the playing cover; black until there is one.
 */
object FadeTone {
    var color by androidx.compose.runtime.mutableStateOf(androidx.compose.ui.graphics.Color.Black)
}

/**
 * Soft edges for a row that scrolls sideways: whatever runs off either side
 * melts away instead of being cut. Always on, and narrow enough to sit inside
 * the row's own start padding, so a row at rest is not dimmed.
 */
fun Modifier.sideFade(width: Dp = 18.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val fade = width.toPx()
        if (fade <= 0f || size.width <= 0f) return@drawWithContent
        val share = (fade / size.width).coerceAtMost(0.5f)
        drawRect(
            brush = Brush.horizontalGradient(
                0f to Color.Black.copy(alpha = 0f),
                share to Color.Black,
                1f - share to Color.Black,
                1f to Color.Black.copy(alpha = 0f),
            ),
            blendMode = BlendMode.DstIn,
        )
    }

/** A LazyRow with [sideFade] on it: every shelf and chip row in the app. */
@androidx.compose.runtime.Composable
fun FadeLazyRow(
    modifier: Modifier = Modifier,
    state: androidx.compose.foundation.lazy.LazyListState = androidx.compose.foundation.lazy.rememberLazyListState(),
    contentPadding: androidx.compose.foundation.layout.PaddingValues = androidx.compose.foundation.layout.PaddingValues(0.dp),
    reverseLayout: Boolean = false,
    horizontalArrangement: androidx.compose.foundation.layout.Arrangement.Horizontal =
        if (!reverseLayout) androidx.compose.foundation.layout.Arrangement.Start else androidx.compose.foundation.layout.Arrangement.End,
    verticalAlignment: androidx.compose.ui.Alignment.Vertical = androidx.compose.ui.Alignment.Top,
    flingBehavior: androidx.compose.foundation.gestures.FlingBehavior =
        androidx.compose.foundation.gestures.ScrollableDefaults.flingBehavior(),
    userScrollEnabled: Boolean = true,
    content: androidx.compose.foundation.lazy.LazyListScope.() -> Unit,
) {
    androidx.compose.foundation.lazy.LazyRow(
        modifier = modifier.sideFade(),
        state = state,
        contentPadding = contentPadding,
        reverseLayout = reverseLayout,
        horizontalArrangement = horizontalArrangement,
        verticalAlignment = verticalAlignment,
        flingBehavior = flingBehavior,
        userScrollEnabled = userScrollEnabled,
        content = content,
    )
}

/**
 * Soft top and bottom edges for a list: rows melt away into the pane instead
 * of being cut through the middle of a line. A long, eased ramp (not a short
 * linear one) so it reads as frosted glass thickening toward the edge.
 */
fun Modifier.verticalEdgeFade(top: Dp = 56.dp, bottom: Dp = 64.dp): Modifier = this
    .graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)
    .drawWithContent {
        drawContent()
        val h = size.height
        if (h <= 0f) return@drawWithContent
        val t = (top.toPx() / h).coerceAtMost(0.45f)
        val b = (bottom.toPx() / h).coerceAtMost(0.45f)
        drawRect(
            brush = Brush.verticalGradient(
                0f to Color.Black.copy(alpha = 0f),
                t * 0.35f to Color.Black.copy(alpha = 0.10f),
                t * 0.70f to Color.Black.copy(alpha = 0.50f),
                t to Color.Black,
                1f - b to Color.Black,
                1f - b * 0.65f to Color.Black.copy(alpha = 0.55f),
                1f - b * 0.30f to Color.Black.copy(alpha = 0.12f),
                1f to Color.Black.copy(alpha = 0f),
            ),
            blendMode = BlendMode.DstIn,
        )
    }
