package dev.lelonio.square.ui.glass

import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.grid.LazyGridState

/** How many rows down a page has to be before the search circle turns into "back to top". */
const val SCROLL_TOP_AFTER_ITEMS = 15

/**
 * Lets the circle beside the mini player know how far down the page in front
 * is, and take it back to the top.
 *
 * Pages register their list while they are on screen; the last one registered
 * is the one the circle follows, so a playlist opened over home is what counts
 * until it is closed.
 */
class ScrollToTopHost {
    private class Entry(val index: () -> Int, val toTop: suspend () -> Unit)

    private val entries = mutableStateListOf<Entry>()

    /** True once the page in front is [SCROLL_TOP_AFTER_ITEMS] rows or more down. */
    val showTop: Boolean by derivedStateOf {
        val current = entries.lastOrNull()
        current != null && current.index() >= SCROLL_TOP_AFTER_ITEMS
    }

    suspend fun scrollToTop() {
        entries.lastOrNull()?.toTop?.invoke()
    }

    internal fun attach(index: () -> Int, toTop: suspend () -> Unit): Any {
        val entry = Entry(index, toTop)
        entries.add(entry)
        return entry
    }

    internal fun detach(token: Any) {
        entries.remove(token)
    }
}

val LocalScrollToTopHost = compositionLocalOf<ScrollToTopHost?> { null }

/** Registers a list with the circle beside the mini player. */
@Composable
fun RegisterScrollToTop(index: () -> Int, toTop: suspend () -> Unit) {
    val host = LocalScrollToTopHost.current ?: return
    DisposableEffect(host) {
        val token = host.attach(index, toTop)
        onDispose { host.detach(token) }
    }
}

@Composable
fun RegisterScrollToTop(state: LazyListState) {
    RegisterScrollToTop({ state.firstVisibleItemIndex }, { state.animateScrollToItem(0) })
}

@Composable
fun RegisterScrollToTop(state: LazyGridState) {
    RegisterScrollToTop({ state.firstVisibleItemIndex }, { state.animateScrollToItem(0) })
}
