package dev.lelonio.square.ui.components

import android.graphics.Bitmap
import android.view.TextureView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * A small copy of what a video's [TextureView] is showing, scaled to [width]
 * by [height].
 *
 * Made with the view's own `getBitmap`, on the main thread where the view
 * expects it. An earlier version took the frame through PixelCopy from a
 * second Surface made on the same SurfaceTexture; on some phones (MIUI among
 * them) that ended the whole process with a native crash (SIGSEGV) as soon
 * as the player with a moving cover was opened.
 *
 * Null when there is nothing to copy yet, or the copy failed.
 */
internal suspend fun TextureView.copyFrame(width: Int, height: Int): Bitmap? {
    if (width <= 0 || height <= 0) return null
    // One copy at a time, whoever asks.
    return copyLock.withLock {
        withContext(Dispatchers.Main.immediate) {
            if (!isAvailable || !isAttachedToWindow) null
            else runCatching { getBitmap(width, height) }.getOrNull()
        }
    }
}

private val copyLock = Mutex()
