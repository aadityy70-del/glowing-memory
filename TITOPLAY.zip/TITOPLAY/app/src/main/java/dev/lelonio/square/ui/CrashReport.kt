package dev.lelonio.square.ui

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Build
import java.io.File

/**
 * A way to learn why the app went away.
 *
 * Writes the stack of any uncaught exception to a file, and on the next start
 * shows it, along with the reason Android gives for the last time the process
 * ended (crash, native crash, out of memory, not responding...). The text can
 * be copied and sent. Nothing leaves the phone by itself.
 */
object CrashReport {
    private const val FILE = "last_crash.txt"
    private const val PREFS = "crash_report"
    private const val KEY_SEEN = "seen_exit_ts"

    fun install(activity: Activity) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            runCatching {
                File(activity.applicationContext.filesDir, FILE)
                    .writeText("Thread: ${thread.name}\n" + error.stackTraceToString())
            }
            previous?.uncaughtException(thread, error)
        }
    }

    fun showIfAny(activity: Activity) {
        val sb = StringBuilder()
        var wantLog = false
        val file = File(activity.filesDir, FILE)
        if (file.exists()) {
            sb.append("Crash:\n").append(file.readText().take(6000)).append('\n')
            file.delete()
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            runCatching {
                val prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                val seen = prefs.getLong(KEY_SEEN, 0L)
                val am = activity.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
                val last = am.getHistoricalProcessExitReasons(activity.packageName, 0, 1).firstOrNull()
                if (last != null && last.timestamp > seen) {
                    prefs.edit().putLong(KEY_SEEN, last.timestamp).apply()
                    // Only a real crash or a hang. Being swiped away, low
                    // memory or the system tidying up are not worth a dialog.
                    val abnormal = when (last.reason) {
                        android.app.ApplicationExitInfo.REASON_CRASH,
                        android.app.ApplicationExitInfo.REASON_CRASH_NATIVE,
                        android.app.ApplicationExitInfo.REASON_ANR -> true
                        else -> false
                    }
                    if (abnormal) {
                        sb.append("Last exit: reason=").append(last.reason)
                            .append(" status=").append(last.status)
                            .append(" description=").append(last.description)
                            .append(" importance=").append(last.importance)
                            .append(" pss=").append(last.pss).append("KB")
                            .append(" rss=").append(last.rss).append("KB\n")
                        wantLog = true
                        // For a native crash or an ANR the system keeps a trace.
                        val raw = runCatching { last.traceInputStream?.use { it.readBytes() } }.getOrNull()
                        if (raw == null) {
                            sb.append("Trace: none kept by the system\n")
                        } else if (last.reason == android.app.ApplicationExitInfo.REASON_CRASH_NATIVE) {
                            sb.append(runCatching { Tombstone.summary(raw) }
                                .getOrElse { "Trace: could not be read (${it.message})\n" })
                        } else {
                            sb.append(String(raw).take(4000))
                        }
                    }
                }
            }
        }
        if (sb.isEmpty()) return
        if (wantLog) {
            // The app may read its own log. The crash's own line (which
            // thread, which address) and what was happening just before it.
            Thread {
                val log = runCatching {
                    val proc = ProcessBuilder("logcat", "-d", "-v", "threadtime", "-t", "4000")
                        .redirectErrorStream(true).start()
                    val lines = proc.inputStream.bufferedReader().readLines()
                    proc.destroy()
                    val at = lines.indexOfLast { "Fatal signal" in it || "SIGSEGV" in it }
                    if (at >= 0) lines.subList((at - 45).coerceAtLeast(0), (at + 8).coerceAtMost(lines.size))
                    else lines.takeLast(25)
                }.getOrNull().orEmpty().joinToString("\n").takeLast(6000)
                if (log.isNotBlank()) sb.append("\nLog:\n").append(log)
                show(activity, sb.toString())
            }.start()
        } else {
            show(activity, sb.toString())
        }
    }

    private fun show(activity: Activity, text: String) {
        activity.window.decorView.post {
            runCatching {
                AlertDialog.Builder(activity)
                    .setTitle("App ended unexpectedly")
                    .setMessage(text)
                    .setPositiveButton("Copy") { _, _ ->
                        val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("TITOPLAY crash", text))
                    }
                    .setNegativeButton("Close", null)
                    .show()
            }
        }
    }
}

/**
 * Reads the system's native crash record (a protobuf "tombstone") far enough
 * to say what crashed: the signal, the address, and the stack of the thread
 * that crashed, then the names of the others.
 */
private object Tombstone {
    private class Reader(val b: ByteArray, var i: Int, val end: Int) {
        fun more() = i < end
        fun varint(): Long {
            var r = 0L
            var shift = 0
            while (true) {
                val c = b[i++].toInt() and 0xff
                r = r or ((c and 0x7f).toLong() shl shift)
                if (c and 0x80 == 0) return r
                shift += 7
            }
        }
        fun len(): Reader {
            val n = varint().toInt()
            val r = Reader(b, i, i + n)
            i += n
            return r
        }
        fun str(): String {
            val n = varint().toInt()
            val s = String(b, i, n)
            i += n
            return s
        }
        fun skip(wire: Int) {
            when (wire) {
                0 -> varint()
                1 -> i += 8
                2 -> i += varint().toInt()
                5 -> i += 4
                else -> i = end
            }
        }
    }

    private class Thread(val id: Long, val name: String, val frames: List<String>)

    fun summary(raw: ByteArray): String {
        val out = StringBuilder()
        var crashTid = -1L
        val threads = mutableListOf<Thread>()
        val top = Reader(raw, 0, raw.size)
        while (top.more()) {
            val tag = top.varint()
            val field = (tag shr 3).toInt()
            val wire = (tag and 7).toInt()
            when {
                field == 6 && wire == 0 -> crashTid = top.varint()
                field == 10 && wire == 2 -> {
                    val r = top.len()
                    var name = ""; var code = ""; var addr = 0L
                    while (r.more()) {
                        val t = r.varint()
                        val f = (t shr 3).toInt(); val w = (t and 7).toInt()
                        when {
                            f == 2 && w == 2 -> name = r.str()
                            f == 4 && w == 2 -> code = r.str()
                            f == 6 && w == 0 -> addr = r.varint()
                            else -> r.skip(w)
                        }
                    }
                    out.append("Signal: $name $code fault_addr=0x${addr.toString(16)}\n")
                }
                field == 14 && wire == 2 -> out.append("Abort: ").append(top.str()).append('\n')
                field == 15 && wire == 2 -> {
                    val r = top.len()
                    while (r.more()) {
                        val t = r.varint()
                        if ((t shr 3).toInt() == 1 && (t and 7).toInt() == 2) {
                            out.append("Cause: ").append(r.str()).append('\n')
                        } else r.skip((t and 7).toInt())
                    }
                }
                field == 16 && wire == 2 -> {
                    val entry = top.len()
                    while (entry.more()) {
                        val t = entry.varint()
                        if ((t shr 3).toInt() == 2 && (t and 7).toInt() == 2) {
                            threads += thread(entry.len())
                        } else entry.skip((t and 7).toInt())
                    }
                }
                else -> top.skip(wire)
            }
        }
        val crashed = threads.firstOrNull { it.id == crashTid }
        if (crashed != null) {
            out.append("Crashed thread: ${crashed.name} (tid ${crashed.id})\n")
            crashed.frames.take(30).forEachIndexed { n, f -> out.append("  #$n $f\n") }
        } else {
            out.append("Crashed tid=$crashTid (not found among ${threads.size} threads)\n")
        }
        out.append("Other threads: ")
            .append(threads.filter { it !== crashed }.joinToString(", ") { it.name })
            .append('\n')
        return out.toString()
    }

    private fun thread(r: Reader): Thread {
        var id = 0L
        var name = ""
        val frames = mutableListOf<String>()
        while (r.more()) {
            val t = r.varint()
            val f = (t shr 3).toInt(); val w = (t and 7).toInt()
            when {
                f == 1 && w == 0 -> id = r.varint()
                f == 2 && w == 2 -> name = r.str()
                f == 4 && w == 2 -> {
                    val fr = r.len()
                    var fn = ""; var file = ""; var off = 0L
                    while (fr.more()) {
                        val ft = fr.varint()
                        val ff = (ft shr 3).toInt(); val fw = (ft and 7).toInt()
                        when {
                            ff == 4 && fw == 2 -> fn = fr.str()
                            ff == 5 && fw == 0 -> off = fr.varint()
                            ff == 6 && fw == 2 -> file = fr.str()
                            else -> fr.skip(fw)
                        }
                    }
                    frames += "${fn.ifEmpty { "?" }}+$off  $file"
                }
                else -> r.skip(w)
            }
        }
        return Thread(id, name, frames)
    }
}
