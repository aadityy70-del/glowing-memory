# TITOPLAY Classic Theme Assets

The optional Classic visual theme uses EB Garamond, Montserrat, and Pinyon Script font files copied from the earlier TITOPLAY/AETHER project. Their original upstream notices and open-font licence details are retained in that project's third_party/NOTICES.md. The supplied TITOPLAY classic mark is a user-provided image asset.
